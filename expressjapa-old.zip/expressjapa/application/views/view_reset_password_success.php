<div class="banner-slider" style="background-image: url(<?php echo base_url(); ?>public/uploads/<?php echo $setting['banner_reset_password_success']; ?>)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>Reset Password Success</h1>
		</div>
	</div>
</div>

<div class="login-area bg-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="login-form" style="padding-top:50px;padding-bottom:50px;font-size:30px;color:green;text-align: center;">
					Password is changed successfully.
				</div>
			</div>
		</div>
	</div>
</div>